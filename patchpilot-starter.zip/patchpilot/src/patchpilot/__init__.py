"""PatchPilot pull-request hygiene checks."""

__version__ = "0.1.0"
