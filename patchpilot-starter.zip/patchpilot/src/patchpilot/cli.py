"""Command-line interface."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

from patchpilot.analyzer import analyze_diff, git_diff, render_markdown, render_text


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="patchpilot", description="Run lightweight checks on a Git pull-request diff.")
    sub = parser.add_subparsers(dest="command", required=True)
    scan = sub.add_parser("scan", help="Analyze changes between BASE and HEAD.")
    scan.add_argument("--base", required=True, help="Base Git ref, for example origin/main.")
    scan.add_argument("--format", choices=("text", "markdown"), default="text", help="Report format.")
    scan.add_argument("--output", type=Path, help="Write report to this file instead of stdout.")
    scan.add_argument("--max-lines", type=int, default=500, help="Warn above this number of added lines.")
    scan.add_argument("--max-files", type=int, default=30, help="Warn above this number of changed files.")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.max_lines < 1 or args.max_files < 1:
        print("Error: --max-lines and --max-files must be positive integers.", file=sys.stderr)
        return 2
    try:
        diff = git_diff(args.base)
        report = analyze_diff(diff, max_changed_lines=args.max_lines, max_files=args.max_files)
    except (RuntimeError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2

    rendered = render_markdown(report) if args.format == "markdown" else render_text(report)
    if args.output:
        try:
            args.output.write_text(rendered, encoding="utf-8")
        except OSError as exc:
            print(f"Error writing report: {exc}", file=sys.stderr)
            return 2
    else:
        print(rendered)
    return 1 if report.has_secret_finding else 0


if __name__ == "__main__":
    raise SystemExit(main())
