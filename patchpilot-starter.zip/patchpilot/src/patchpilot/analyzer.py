"""Analyze Git diff text using small, explainable heuristics."""

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class Finding:
    severity: str
    rule: str
    message: str
    path: str | None = None
    line: int | None = None


@dataclass(frozen=True)
class Analysis:
    files: tuple[str, ...]
    changed_lines: int
    findings: tuple[Finding, ...]

    @property
    def has_secret_finding(self) -> bool:
        return any(f.rule == "possible-secret" for f in self.findings)


# Deliberately conservative starter patterns. These are not a complete secret scanner.
_SECRET_PATTERNS = (
    ("private-key", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----")),
    ("github-token", re.compile(r"\bgh[pousr]_[A-Za-z0-9_]{20,}\b")),
    ("openai-key", re.compile(r"\bsk-[A-Za-z0-9_-]{20,}\b")),
    ("aws-access-key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("generic-assignment", re.compile(
        r"""(?i)\b(?:api[_-]?key|access[_-]?token|client[_-]?secret|password)\b\s*[:=]\s*["'][^"']{8,}["']"""
    )),
)

_TEST_PARTS = ("test", "tests", "spec", "specs")
_DOC_PARTS = ("readme", "docs", "documentation")


def _is_test_path(path: str) -> bool:
    lower = path.lower()
    parts = lower.replace("\\", "/").split("/")
    return any(part in _TEST_PARTS or part.startswith("test_") for part in parts) or Path(lower).name.startswith("test_")


def _is_doc_path(path: str) -> bool:
    lower = path.lower().replace("\\", "/")
    name = Path(lower).name
    return name.startswith("readme") or name.endswith((".md", ".rst", ".adoc")) or any(
        part in _DOC_PARTS for part in lower.split("/")
    )


def _looks_like_source(path: str) -> bool:
    return Path(path).suffix.lower() in {
        ".py", ".js", ".jsx", ".ts", ".tsx", ".go", ".rs", ".java", ".c", ".h", ".cpp", ".cs", ".rb", ".php"
    }


def analyze_diff(diff_text: str, *, max_changed_lines: int = 500, max_files: int = 30) -> Analysis:
    """Analyze unified diff text. Secret values are never included in findings."""
    files: list[str] = []
    findings: list[Finding] = []
    changed_lines = 0
    current_file: str | None = None
    new_line_number: int | None = None

    for line in diff_text.splitlines():
        if line.startswith("+++ "):
            raw = line[4:].strip()
            current_file = None if raw == "/dev/null" else raw.removeprefix("b/")
            if current_file and current_file not in files:
                files.append(current_file)
            new_line_number = None
            continue
        if line.startswith("@@ "):
            match = re.search(r"\+(\d+)(?:,(\d+))?", line)
            new_line_number = int(match.group(1)) if match else None
            continue
        if line.startswith("+") and not line.startswith("+++"):
            changed_lines += 1
            if current_file:
                for rule, pattern in _SECRET_PATTERNS:
                    if pattern.search(line[1:]):
                        findings.append(Finding(
                            "high", "possible-secret",
                            f"Added line matches the '{rule}' credential pattern. Inspect and rotate any real credential; the value is redacted.",
                            current_file, new_line_number
                        ))
                        break
            if new_line_number is not None:
                new_line_number += 1
        elif line.startswith("-") and not line.startswith("---"):
            # Removed lines do not count as newly added lines.
            continue
        elif not line.startswith("\\") and new_line_number is not None:
            new_line_number += 1

    if changed_lines > max_changed_lines:
        findings.append(Finding(
            "medium", "large-change",
            f"Diff adds {changed_lines} lines, above the configured limit of {max_changed_lines}. Consider splitting the change."
        ))
    if len(files) > max_files:
        findings.append(Finding(
            "medium", "many-files",
            f"Diff touches {len(files)} files, above the configured limit of {max_files}. Consider splitting the change."
        ))

    source_files = [p for p in files if _looks_like_source(p)]
    if source_files and not any(_is_test_path(p) for p in files):
        findings.append(Finding(
            "low", "tests-not-obvious",
            "Source files changed, but no test-related path was detected. Confirm tests are included or explain why they are unnecessary."
        ))
    if source_files and not any(_is_doc_path(p) for p in files):
        findings.append(Finding(
            "low", "docs-not-obvious",
            "Source files changed, but no documentation path was detected. Consider whether user-facing docs need updating."
        ))

    return Analysis(tuple(files), changed_lines, tuple(findings))


def git_diff(base: str, *, cwd: str | Path = ".") -> str:
    """Return diff for BASE...HEAD. Raises RuntimeError on Git errors."""
    if not base or base.startswith("-"):
        raise ValueError("Base must be a Git ref, not an option.")
    try:
        result = subprocess.run(
            ["git", "diff", "--no-ext-diff", "--unified=0", f"{base}...HEAD", "--"],
            cwd=str(cwd), check=False, capture_output=True, text=True, timeout=30,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise RuntimeError(f"Could not run git diff: {exc}") from exc
    if result.returncode != 0:
        # Git's stderr can include repository paths, but not source diff contents.
        raise RuntimeError(f"git diff failed: {result.stderr.strip() or 'unknown Git error'}")
    return result.stdout


def render_text(analysis: Analysis) -> str:
    lines = [
        "PatchPilot report",
        f"Changed files: {len(analysis.files)}",
        f"Added lines: {analysis.changed_lines}",
        f"Findings: {len(analysis.findings)}",
        "",
    ]
    if not analysis.findings:
        lines.append("No configured checks raised a finding. This is not a guarantee of security or correctness.")
    for item in analysis.findings:
        location = ""
        if item.path:
            location = f" ({item.path}"
            if item.line is not None:
                location += f":{item.line}"
            location += ")"
        lines.append(f"[{item.severity.upper()}] {item.rule}{location}: {item.message}")
    return "\n".join(lines)


def render_markdown(analysis: Analysis) -> str:
    lines = [
        "## PatchPilot report",
        "",
        f"- **Changed files:** {len(analysis.files)}",
        f"- **Added lines:** {analysis.changed_lines}",
        f"- **Findings:** {len(analysis.findings)}",
        "",
    ]
    if not analysis.findings:
        lines.append("No configured checks raised a finding. This is not a guarantee of security or correctness.")
    for item in analysis.findings:
        location = ""
        if item.path:
            location = f" in `{item.path}"
            if item.line is not None:
                location += f":{item.line}"
            location += "`"
        lines.append(f"- **{item.severity.upper()} — `{item.rule}`**{location}: {item.message}")
    return "\n".join(lines) + "\n"
