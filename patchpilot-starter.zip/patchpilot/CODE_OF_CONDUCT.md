# Code of Conduct

We want participation in PatchPilot to be welcoming and respectful.

Expected behavior:
- Be respectful and constructive.
- Focus criticism on code and ideas, not people.
- Welcome beginner questions and differing perspectives.
- Respect privacy and never publish another person's private information.

Harassment, discrimination, threats, personal attacks, and sharing private information without consent are not acceptable. Maintainers may remove content or restrict participation to keep the community safe.
