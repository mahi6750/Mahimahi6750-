# Security Policy

## Project status

PatchPilot is an early prototype. Its heuristics are not a complete secret scanner or security audit.

## Reporting a vulnerability

Please do not publish real credentials, private code, or exploit details in a public issue. Use GitHub private vulnerability reporting for this repository if enabled; otherwise contact the maintainer through the contact method on the GitHub profile.

## Safe handling

- PatchPilot should not send diffs or source code over the network.
- Possible secret findings must never include the matched credential value.
- Treat findings as leads for human review, not definitive security conclusions.
- Do not run automated checks against repositories you do not own or have permission to review.
