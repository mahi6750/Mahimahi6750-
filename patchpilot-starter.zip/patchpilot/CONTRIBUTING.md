# Contributing

Thanks for considering contributing to PatchPilot.

## Setup

Python 3.10+ and Git are required.

```bash
python -m pip install -e ".[dev]"
pytest
```

## Pull requests

- Explain the problem and expected behavior.
- Add tests for new behavior and bug fixes.
- Keep the changes focused and update docs when user behavior changes.
- Never commit API keys, real credentials, private diffs, or personal data.
- Do not make the tool upload code or diffs without explicit opt-in and clear documentation.

## Reporting issues

Include the Python version, operating system, command used, and a minimal sanitized example. Remove credentials and private repository details before posting.
