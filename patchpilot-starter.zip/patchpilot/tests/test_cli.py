from patchpilot.cli import main


def test_invalid_threshold_returns_error(capsys):
    assert main(["scan", "--base", "main", "--max-lines", "0"]) == 2
    assert "positive integers" in capsys.readouterr().err
