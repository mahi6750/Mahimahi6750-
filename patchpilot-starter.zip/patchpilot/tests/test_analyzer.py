from patchpilot.analyzer import analyze_diff, render_markdown, render_text


def test_counts_added_lines_and_files():
    diff = """diff --git a/src/app.py b/src/app.py
--- a/src/app.py
+++ b/src/app.py
@@ -1,0 +1,2 @@
+print("hello")
+print("world")
"""
    result = analyze_diff(diff)
    assert result.changed_lines == 2
    assert result.files == ("src/app.py",)


def test_detects_secret_without_echoing_value():
    secret = "sk-" + "A" * 30
    diff = f"""diff --git a/config.py b/config.py
--- /dev/null
+++ b/config.py
@@ -0,0 +1 @@
+API_KEY = "{secret}"
"""
    result = analyze_diff(diff)
    assert result.has_secret_finding
    assert secret not in render_text(result)
    assert secret not in render_markdown(result)


def test_removed_secret_is_not_flagged_as_new():
    diff = """diff --git a/config.py b/config.py
--- a/config.py
+++ b/config.py
@@ -1 +0,0 @@
-API_KEY = "sk-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
"""
    # This line is shown as removed by a valid diff, so it must not be scanned as added.
    result = analyze_diff(diff)
    assert not result.has_secret_finding


def test_warns_when_tests_and_docs_not_obvious():
    diff = """diff --git a/src/app.py b/src/app.py
--- a/src/app.py
+++ b/src/app.py
@@ -1 +1 @@
-old()
+new()
"""
    rules = {f.rule for f in analyze_diff(diff).findings}
    assert "tests-not-obvious" in rules
    assert "docs-not-obvious" in rules


def test_test_path_avoids_test_warning():
    diff = """diff --git a/src/app.py b/src/app.py
--- a/src/app.py
+++ b/src/app.py
@@ -1 +1 @@
-old()
+new()
diff --git a/tests/test_app.py b/tests/test_app.py
--- /dev/null
+++ b/tests/test_app.py
@@ -0,0 +1 @@
+def test_new(): pass
"""
    rules = {f.rule for f in analyze_diff(diff).findings}
    assert "tests-not-obvious" not in rules


def test_large_change_threshold_is_configurable():
    diff = """diff --git a/readme.md b/readme.md
--- /dev/null
+++ b/readme.md
@@ -0,0 +1,3 @@
+a
+b
+c
"""
    assert "large-change" in {f.rule for f in analyze_diff(diff, max_changed_lines=2).findings}
