# PatchPilot

**A small, transparent pull-request hygiene checker for GitHub projects.**

PatchPilot analyzes the changes in a Git diff and reports practical review signals: unusually large changes, missing tests or documentation, and possible secrets in added lines. It is designed to run locally or in GitHub Actions.

> Status: early prototype. Findings are heuristics, not proof of a vulnerability or a replacement for human review.

## Why PatchPilot?

Reviewers often need quick answers to basic questions before reading a pull request: Is it unusually large? Are tests included? Is documentation likely needed? Did a credential accidentally enter the diff? PatchPilot makes those checks repeatable and produces a Markdown report.

## Requirements

- Python 3.10+
- Git installed
- A local Git repository with the base commit available

No third-party Python dependencies are required.

## Run locally

```bash
python -m pip install -e .
patchpilot scan --base origin/main
```

Or run without installing:

```bash
python -m patchpilot scan --base origin/main
```

For a report file:

```bash
patchpilot scan --base origin/main --format markdown --output patchpilot-report.md
```

PatchPilot compares `BASE...HEAD` using Git. Make sure the base ref exists locally. In a CI workflow, fetch sufficient history before running it.

## Checks

- **Change size:** warns when a diff exceeds configurable changed-line or file thresholds.
- **Tests:** notes when code changes do not appear to include test changes.
- **Documentation:** notes when source changes do not appear to include documentation changes.
- **Possible secrets:** checks added diff lines against a small set of common credential patterns. It reports the rule and file/line, never the matched value.
- **Exit codes:** `0` when no high-severity findings are reported; `1` when a possible secret is detected; `2` when the command cannot run.

These are deliberately lightweight heuristics. A clean report does not mean code is secure, and a pattern match may be a false positive. Review findings before acting on them.

## GitHub Actions

A sample workflow is included in `.github/workflows/patchpilot.yml`. Copy or adapt it to your project. Review permissions and pin third-party actions according to your own supply-chain policy before using it in a production repository.

## Privacy

PatchPilot runs locally and does not send diffs or source code to an external service. It does not use an AI API. If an AI integration is added in the future, it should be opt-in, documented, and designed to avoid sending secrets.

## Development

```bash
python -m pip install -e ".[dev]"
pytest
```

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). Please include tests for behavior changes and never submit real credentials or private source code in issues.

## Security

Read [SECURITY.md](SECURITY.md) for responsible vulnerability reporting.

## Roadmap

- [x] Initial Git diff analyzer
- [x] Basic secret-pattern checks that redact values
- [x] Human-readable and Markdown reports
- [x] Unit tests and CI workflow
- [ ] Configurable rules in a project file
- [ ] GitHub pull-request annotations
- [ ] Optional, explicitly enabled AI review
- [ ] Broader tests against real-world public diffs

## License

MIT. See [LICENSE](LICENSE).
